#include "ofApp.h"


int stageLengths[] = {20, 10, 10};
//--------------------------------------------------------------
void ofApp::setup(){
    ofSetFrameRate( 60 );
    ofSetFullscreen(true);
    svg.load( "website2.svg" );
    cout << svg.toString();
    
//    
//    vector< shared_ptr<ofxSvgImage> > icons = svg.getElementsForType< ofxSvgImage>("icons");
//    for( int i = 0; i < icons.size(); i++ ) {
//        icons[i]->img.setAnchorPercent( 0.5, 1.f );
//        icons[i]->pos.x += icons[i]->getWidthScaled()/2;
//        icons[i]->pos.y += icons[i]->getHeightScaled();
//    }
    
}

//--------------------------------------------------------------
void ofApp::update(){
    
    
    shared_ptr<ofxSvgGroup> toysGroup = svg.get< ofxSvgGroup>("toys");
    shared_ptr<ofxSvgGroup> booksGroup = svg.get< ofxSvgGroup>("books");
    shared_ptr<ofxSvgGroup> artsGroup = svg.get< ofxSvgGroup>("arts");
    shared_ptr<ofxSvgGroup> computersGroup = svg.get< ofxSvgGroup>("computers");
    shared_ptr<ofxSvgGroup> electronicsGroup = svg.get< ofxSvgGroup>("electronics");
    shared_ptr<ofxSvgGroup> textGroup = svg.get< ofxSvgGroup>("text");
    shared_ptr<ofxSvgGroup> iconsGroup = svg.get< ofxSvgGroup>("icons");
    shared_ptr<ofxSvgGroup> backgroundGroup = svg.get< ofxSvgGroup>("background");
    shared_ptr<ofxSvgGroup> bannerGroup = svg.get< ofxSvgGroup>("banner");
    
    
//    vector< shared_ptr<ofxSvgImage> > icons = svg.getElementsForType< ofxSvgImage>("icons");
//    float mouseX = ofGetMouseX();
//
//    for( int i = 0; i < icons.size(); i++ ) {
//        float dist = fabs( icons[i]->pos.x - mouseX);
//        float tscale = ofMap( dist, 85, 100, 1.2, 1.0, true );
//        icons[i]->scale.set( tscale, tscale );
//    }
    
    
    
    //inital state change triggered by hand pos. in relation to svg element
    timer += ofGetLastFrameTime();
    
    if (timer >= stageLengths[stage]) {
        stage++;
        timer = 0;
    } if (stage > 3){
        stage = 0;
    }
    
    
    
}

//--------------------------------------------------------------
void ofApp::draw(){
    //svg.draw();
    
    //homepage
    if(stage==0) {
        svg.draw();
    }
    
    //alternate page element
    else if(stage==1){
        
    }
    
    //alternate page element
    else if(stage==2){
        //orbbecastra draw at .....
        
    }
    
}

//--------------------------------------------------------------
void ofApp::keyPressed(int key){
    
}

//--------------------------------------------------------------
void ofApp::keyReleased(int key){
    
}

//--------------------------------------------------------------
void ofApp::mouseMoved(int x, int y ){
    
}

//--------------------------------------------------------------
void ofApp::mouseDragged(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mousePressed(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseReleased(int x, int y, int button){
    
}

//--------------------------------------------------------------
void ofApp::mouseEntered(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::mouseExited(int x, int y){
    
}

//--------------------------------------------------------------
void ofApp::windowResized(int w, int h){
    
}

//--------------------------------------------------------------
void ofApp::gotMessage(ofMessage msg){
    
}

//--------------------------------------------------------------
void ofApp::dragEvent(ofDragInfo dragInfo){
    
}


